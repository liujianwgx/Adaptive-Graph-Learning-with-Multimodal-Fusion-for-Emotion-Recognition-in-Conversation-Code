import sys
import random
import logging
import os
import numpy as np
import torch
import pickle
import umap  
import matplotlib.pyplot as plt  
import seaborn as sns  
from sklearn import metrics

def set_seed(seed):
    """Sets random seed everywhere."""
    print("Seed set")
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True  # use determinisitic algorithm


def get_logger(level=logging.INFO):
    log = logging.getLogger(__name__)
    if log.handlers:
        return log
    log.setLevel(level)
    ch = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(
        fmt="%(asctime)s %(message)s", datefmt="%m/%d/%Y %I:%M:%S"
    )
    ch.setFormatter(formatter)
    log.addHandler(ch)
    return log


def save_pkl(obj, file):
    with open(file, "wb") as f:
        pickle.dump(obj, f)


def load_pkl(file):
    with open(file, "rb") as f:
        return pickle.load(f)

def save_model(args, model):
    out = os.path.join(args.cl_model_path, "checkpoint_{}.tar".format(args.current_epoch))
    torch.save(model.state_dict(), out)

def find_dataset_key(labels, dataset_label_dict):
    for dataset_name, label_dict in dataset_label_dict.items():
        dict_values_set = label_dict
        if dict_values_set == labels:
            return dataset_name
    return None  # 未找到匹配项时返回None

def draw_Umap(args,tensor,labels,titlename):
    dataset_label_dict = {
        "iemocap": {"hap": 0, "sad": 1, "neu": 2, "ang": 3, "exc": 4, "fru": 5},
        "iemocap_4": {"hap": 0, "sad": 1, "neu": 2, "ang": 3},
        "mosei": {
            "Strong Negative": 0,
            "Negative": 1,
            "Weak Negative": 2,
            "Neutral": 3,
            "Weak Positive": 4,
            "Positive": 5,
            "Strong Positive": 6,
        },
        "mosei_2": {"Negative": 0, "Positive": 1},
    }

    label_to_idx = dataset_label_dict[args.dataset]

    # pool_hidden_state = torch.mean(features,dim=1).cpu().detach().numpy()
    embedding=umap.UMAP(n_components=2).fit_transform(tensor.cpu().detach().numpy())
    labels=labels.cpu().detach().numpy()
    # colors = [label_to_idx[yi] for yi in labels]
    colors = [find_dataset_key(yi,label_to_idx) for yi in labels]
    
    plt.figure(figsize=(8, 6))  
    sns.scatterplot(x=embedding[:, 0], y=embedding[:, 1], hue=colors, legend="auto",palette="Set1",sizes=10)
    plt.gca().set_aspect("equal","datalim")
    plt.title(titlename)  
    plt.xlabel('UMAP Dimension 1')  
    plt.ylabel('UMAP Dimension 2')
    plt.gca().axes.get_xaxis().set_visible(False)  # 隐藏x轴  
    plt.gca().axes.get_yaxis().set_visible(False)  # 隐藏y轴 
    plt.show()

