import numpy as np
import torch 
import torch.nn as nn
import torch.nn.functional as F
from torch import einsum
from einops import rearrange, repeat, reduce
from einops.layers.torch import Rearrange, Reduce
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class Varied_Size_Window(nn.Module):
    def __init__(self,dim,vsw_dim,out_size,args):
        super().__init__()
        self.dim=dim
        self.vsw_dim=vsw_dim
        self.args=args
        self.drop = nn.Dropout(args.drop_rate_vsw) 
        
        self.lin1 = nn.Linear(dim, vsw_dim)
        # self.lin2 = nn.Linear(vsw_dim, vsw_dim)
        self.lin_out = nn.Linear(vsw_dim, out_size)
        self.ln1=nn.LayerNorm(vsw_dim)
        # self.ln2=nn.LayerNorm(vsw_dim)
        # self.relu=nn.ReLU(inplace=True)
        # self.gelu=nn.GELU()

    def get_grob(self,h):
        # x=self.lin1(h)
        # # _x=x
        # x=self.ln1(x)
        # x=self.gelu(x)
        # x=self.lin2(x)
        # x=self.ln2(x)
        # hidden=self.gelu(x+_x)
        



        # x=self.drop(F.relu(self.lin1(h)))
        # x=self.drop(F.relu(self.lin2(x)))
       
        

        hidden=self.drop(F.relu(self.lin1(h)))

        if self.args.emotion == "7class":
            scores = self.lin_7(hidden)
        else:
            scores = self.lin_out(hidden)
        log_prob = F.log_softmax(scores, dim=1)
        return log_prob
        

    def forward(self,x):
       
        # x=rearrange(x,"b l c -> b c l")
        sampling_scales=self.get_grob(x)
        # sampling_scales=rearrange(sampling_scales,"b c l -> b l c")
        scales = torch.argmax(sampling_scales, dim=-1)
        return scales
  
