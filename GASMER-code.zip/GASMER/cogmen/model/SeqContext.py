import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
from cogmen.model.transformer_ProbAttention import *
from cogmen.model.transformer import TransformerEncoderLayer
from cogmen.model.adapter import FFN_Adapter
import math



# class Transformer_adapter_block(nn.Module):
#     def __init__(self,args,input_size,adapter_input_size,nhead,drop_rate):
#         super(Transformer_adapter_block, self).__init__()
#         self.layer = nn.ModuleList()
#         self.layer.append(TransformerEncoderLayer(
#             d_model=input_size,
#             nhead=nhead,
#             dropout=drop_rate,
#             batch_first=True,
#         ))
#         self.layer.append(FFN_Adapter(args,adapter_input_size))

#     def forward(self,hidden_states,audio_tensor,video_tensor):
#         transformer_layer=self.layer[0]
#         adapter_layer=self.layer[1]
#         hidden_states=transformer_layer(hidden_states)
#         hidden_states=adapter_layer(hidden_states,visual=video_tensor,acoustic=audio_tensor)
#         return hidden_states




class SeqContext(nn.Module):
    def __init__(self, u_dim, g_dim, args,experiment=None):
        super(SeqContext, self).__init__()
        self.input_size = u_dim
        self.hidden_dim = g_dim
        self.device = args.device
        self.dropout = nn.Dropout(args.drop_rate)
        self.args = args
        if args.use_multimodel_adapter:
            self.input_size = args.dataset_embedding_dims[args.dataset]["t"]
            self.adapter_size = args.dataset_embedding_dims[args.dataset][args.modalities]
        else:
            self.input_size = args.dataset_embedding_dims[args.dataset][args.modalities]
        
        self.nhead = 1
        for h in range(7, 15):
            if self.input_size % h == 0:
                self.nhead = h
                break

        self.encoding_layer = nn.Embedding(110, self.input_size)
        self.LayerNorm = nn.LayerNorm(self.input_size)

        if args.log_in_comet and not args.tuning:
            experiment.log_parameter(
                "input_feature_dims", self.input_size, step=None
            )
            experiment.log_parameter("nheads_in_SeqContext", self.nhead, step=None)

        self.use_transformer = False
        if args.rnn == "lstm":
            print("SeqContext-> USING LSTM")
            self.rnn = nn.LSTM(
                self.input_size,
                self.hidden_dim // 2,
                dropout=args.drop_rate,
                bidirectional=True,
                num_layers=args.seqcontext_nlayer,
                batch_first=True,
            )
        elif args.rnn == "gru":
            print("SeqContext-> USING GRU")
            self.rnn = nn.GRU(
                self.input_size,
                self.hidden_dim // 2,
                dropout=args.drop_rate,
                bidirectional=True,
                num_layers=args.seqcontext_nlayer,
                batch_first=True,
            )
        elif args.rnn == "transformer":
            print("SeqContext-> USING Transformer")
            self.use_transformer = True

            if args.use_probAttention:
                print("USING probAttention")
                Attn=ProbAttention
                if args.use_multimodel_adapter:
                    print("USING multimodel_adapter")
                    self.transformer_encoder=Encoder(
                        [
                            EncoderLayer(
                                AttentionLayer(Attn(False, factor=5, attention_dropout=args.drop_rate, output_attention=False), 
                                            d_model=self.input_size, n_heads=self.nhead, mix=False),
                                d_model=self.input_size,
                                d_ff=2048,
                                dropout=args.drop_rate,
                                activation="relu"
                            ) for l in range(args.seqcontext_nlayer)
                        ],
                        [
                            FFN_Adapter(
                                args,
                                self.adapter_size
                            ) for l in range(args.seqcontext_nlayer)
                        ],
                        norm_layer=torch.nn.LayerNorm(self.input_size)
                    )
                    self.transformer_out = torch.nn.Linear(
                        self.input_size, self.hidden_dim, bias=True
                    )
                else:
                    self.transformer_encoder=Encoder(
                        [
                            EncoderLayer(
                                AttentionLayer(Attn(False, factor=5, attention_dropout=args.drop_rate, output_attention=False), 
                                            d_model=self.input_size, n_heads=self.nhead, mix=False),
                                d_model=self.input_size,
                                d_ff=2048,
                                dropout=args.drop_rate,
                                activation="relu"
                            ) for l in range(args.seqcontext_nlayer)
                        ],
                        norm_layer=torch.nn.LayerNorm(self.input_size)
                    )
                    self.transformer_out = torch.nn.Linear(
                        self.input_size, self.hidden_dim, bias=True
                    )

            else:
                encoder_layer = torch.nn.TransformerEncoderLayer(
                    d_model=self.input_size,
                    nhead=self.nhead,
                    dropout=args.drop_rate,
                    batch_first=True,
                )
                self.transformer_encoder = torch.nn.TransformerEncoder(
                    encoder_layer, num_layers=args.seqcontext_nlayer
                )
                self.transformer_out = torch.nn.Linear(
                    self.input_size, self.hidden_dim, bias=True
                )
            print("args.drop_rate:", args.drop_rate)

    def forward(self, text_len_tensor, text_tensor,audio_tensor=None,video_tensor=None):
        if self.use_transformer:
            if self.args.use_multimodel_adapter:
                rnn_out=self.transformer_encoder(text_tensor,audio_tensor,video_tensor)
                rnn_out=self.transformer_out(rnn_out)
            else:
                rnn_out = self.transformer_encoder(text_tensor)
                rnn_out = self.transformer_out(rnn_out)
        else:
            packed = pack_padded_sequence(
                text_tensor, text_len_tensor, batch_first=True, enforce_sorted=False
            )
            rnn_out, (_, _) = self.rnn(packed, None)
            rnn_out, _ = pad_packed_sequence(rnn_out, batch_first=True)

        return rnn_out

    def swish(self, x):
        """https://arxiv.org/abs/1710.05941"""
        return x * torch.sigmoid(x)
