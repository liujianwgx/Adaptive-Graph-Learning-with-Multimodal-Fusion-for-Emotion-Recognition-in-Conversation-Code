import torch
from torch import nn
from torch.nn import CrossEntropyLoss, MSELoss
import logging
import  os
import math
import torch.nn.functional as F
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import os
import argparse
from cogmen import utils

# logger = logging.getLogger(__name__)
# parser=argparse.ArgumentParser(description="SimCLR")
# config=utils.yaml_config_hook("/home/jiawei/COGMEN/COGMEN/config/config.yaml")
# for k,v in config.items():
#     parser.add_argument(f"--{k}",default=v,type=type(v))
# args=parser.parse_args()


class AdapterConfig:
    adapter_size: int = 200  # 64
    adapter_initializer_range: float = 0.001
    attention_probs_dropout_prob: float = 0.1
    out_hidden_size: int = 768

class FFN_Adapter(nn.Module):
    #### 考虑的是多模态的情况
    def __init__(self,args,input_dim):
        super(FFN_Adapter, self).__init__()
        self.adapter_config =  AdapterConfig()
        in_dim = input_dim
        self.adapter_down_project = nn.Linear(in_dim,self.adapter_config.adapter_size)
        self.adapter_up_project = nn.Linear(self.adapter_config.adapter_size,in_dim)
        self.adapter_down_project.weight = torch.nn.Parameter(torch.normal(mean=0.0, std=self.adapter_config.adapter_initializer_range,
                                                                   size=(self.adapter_config.adapter_size, in_dim,)))
        self.adapter_down_project.bias = torch.nn.Parameter(torch.zeros(self.adapter_config.adapter_size))

        self.adapter_up_project.weight = torch.nn.Parameter(torch.normal(mean=0.0, std=self.adapter_config.adapter_initializer_range,
                                                    size=(in_dim, self.adapter_config.adapter_size,)))
        self.adapter_up_project.bias = torch.nn.Parameter(torch.zeros(in_dim))
        self.adapter_linear = nn.Linear(in_dim,self.adapter_config.out_hidden_size)
        self.args=args
####
    def forward(self, hidden_states, audio=None,visual=None):
        ### visualization应该保存第几个adapter的可视化结果
        if self.args.modalities=="atv":
            hidden_states = torch.cat([audio,hidden_states,visual], dim=-1)
        if self.args.modalities=="at":
            hidden_states = torch.cat([audio,hidden_states], dim=-1)
        if self.args.modalities=="tv":
            hidden_states = torch.cat([hidden_states,visual], dim=-1)
        if self.args.modalities=="t":
            hidden_states = torch.cat([hidden_states], dim=-1)
        
            
        down_output = self.adapter_down_project(hidden_states)
        # down_output_nolinear = F.sigmoid(down_output)
        down_output_nolinear = F.relu(down_output)
        up_output = self.adapter_up_project(down_output_nolinear)
        output = up_output + hidden_states
        output=self.adapter_linear(output)

            
        # if args.adapter_visualize:
        #     ###先尝试只做一个batch size内的可视化
        #     pool_hidden_state = torch.mean(hidden_states,dim=1).cpu().detach().numpy()
            
        #     X_tsne = TSNE(n_components=2,random_state=33).fit_transform(pool_hidden_state)
        #     X_pca = PCA(n_components=2).fit_transform(pool_hidden_state)

        #     ckpt_dir="images"
        #     if not os.path.exists(ckpt_dir):
        #         os.makedirs(ckpt_dir)

        #     plt.figure(figsize=(10, 5))
        #     plt.subplot(121)
        #     plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=None,label="t-SNE")
        #     plt.legend()
        #     plt.subplot(122)
        #     plt.scatter(X_pca[:, 0], X_pca[:, 1], c=None,label="PCA")
        #     plt.legend()
        #     plt.savefig('images/orig_tsne-pca_{}.png'.format(str(id)), dpi=120)
        #     # plt.show()
            
        #     pool_fusion = torch.mean(output, dim=1).cpu().detach().numpy()
            
        #     X_tsne = TSNE(n_components=2,random_state=33).fit_transform(pool_fusion)
        #     X_pca = PCA(n_components=2).fit_transform(pool_fusion)


        #     plt.figure(figsize=(10, 5))
        #     plt.subplot(121)
        #     plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=None,label="t-SNE")
        #     plt.legend()
        #     plt.subplot(122)
        #     plt.scatter(X_pca[:, 0], X_pca[:, 1], c=None,label="PCA")
        #     plt.legend()
        #     plt.savefig('images/fusion_tsne-pca_{}.png'.format(str(id)), dpi=120)
        #     # plt.show()
            
            

        return output


    def init_weights(self):
        self.down_project.weight.data.normal_(mean=0.0, std=self.adapter_config.adapter_initializer_range)
        self.down_project.bias.data.zero_()
        self.up_project.weight.data.normal_(mean=0.0, std=self.adapter_config.adapter_initializer_range)
        self.up_project.bias.data.zero_()

