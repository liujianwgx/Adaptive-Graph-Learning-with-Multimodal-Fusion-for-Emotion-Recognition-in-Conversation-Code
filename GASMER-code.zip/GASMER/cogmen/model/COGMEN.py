import torch
import torch.nn as nn
import torch.nn.functional as F

from .SeqContext import SeqContext
from .GNN import GNN
from .Classifier import Classifier
from .VSW import Varied_Size_Window
from .functions import batch_graphify,getStat,vsw_batch_graphify,get_masked_features,get_random_mask,batch_flatten
import cogmen
from cogmen.utils import draw_Umap

log = cogmen.utils.get_logger()


class COGMEN(nn.Module):
    def __init__(self, args,experiment=None):
        super(COGMEN, self).__init__()
        u_dim = 100
        if args.rnn == "transformer":
            g_dim = args.hidden_size
        else:
            g_dim = 200
        h1_dim = args.hidden_size
        h2_dim = args.hidden_size
        hc_dim = args.hidden_size
        vsw_dim=args.hidden_size
        dataset_label_dict = {
            "iemocap": {"hap": 0, "sad": 1, "neu": 2, "ang": 3, "exc": 4, "fru": 5},
            "iemocap_4": {"hap": 0, "sad": 1, "neu": 2, "ang": 3},
            "mosei": {
                "Strong Negative": 0,
                "Negative": 1,
                "Weak Negative": 2,
                "Neutral": 3,
                "Weak Positive": 4,
                "Positive": 5,
                "Strong Positive": 6,
            },
            "mosei_2": {"Negative": 0, "Positive": 1},
        }

        dataset_speaker_dict = {
            "iemocap": 2,
            "iemocap_4": 2,
            "mosei": 1,
            "mosei_2":1,
        }

        if args.dataset and args.emotion == "multilabel":
            dataset_label_dict["mosei"] = {
                "happiness": 0,
                "sadness": 1,
                "anger": 2,
                "surprise": 3,
                "disgust": 4,
                "fear": 5,
            }

        window_tag_size=16
        tag_size = len(dataset_label_dict[args.dataset])
        args.n_speakers = dataset_speaker_dict[args.dataset]
        self.concat_gin_gout = args.concat_gin_gout

        self.wp = args.wp
        self.wf = args.wf
        self.device = args.device

        self.rnn = SeqContext(u_dim, g_dim, args,experiment)
        if args.use_graph_generator:
            print("USING graph_generator")
            self.vsw=Varied_Size_Window(vsw_dim,64,window_tag_size,args)
            self.gcn_dae = GNN(g_dim, h1_dim, g_dim, args)
            self.projection=nn.Linear(h2_dim* args.gnn_nheads,g_dim)
        self.gcn = GNN(g_dim, h1_dim, h2_dim, args)

        if args.concat_gin_gout:
            self.clf = Classifier(
                g_dim + h2_dim * args.gnn_nheads, hc_dim, tag_size, args
            )
        else:
            self.clf = Classifier(h2_dim * args.gnn_nheads, hc_dim, tag_size, args)


        edge_type_to_idx = {}
        for j in range(args.n_speakers):
            for k in range(args.n_speakers):
                edge_type_to_idx[str(j) + str(k) + "0"] = len(edge_type_to_idx)
                edge_type_to_idx[str(j) + str(k) + "1"] = len(edge_type_to_idx)
        self.edge_type_to_idx = edge_type_to_idx

        self.args=args
        log.debug(self.edge_type_to_idx)

    def get_rep(self, data):
        # [batch_size, mx_len, D_g]
        if self.args.use_multimodel_adapter:
            node_features = self.rnn(data["text_len_tensor"], data["text_tensor"],data["audio_tensor"],data["video_tensor"])
        else:
            node_features = self.rnn(data["text_len_tensor"], data["input_tensor"])


        if self.args.use_graph_generator:
            mask=get_random_mask(node_features,self.args.mask_ratio).to(self.device)
            masked_features =get_masked_features(node_features,mask,self.args.noise_type,self.args)
            window_size=self.vsw(masked_features)

            features, edge_index, edge_type, edge_index_lengths = vsw_batch_graphify(
                node_features,
                data["text_len_tensor"],
                data["speaker_tensor"],
                window_size,
                self.edge_type_to_idx,
                self.device,
            )
            if self.args.visualize:
                draw_Umap(self.args,features,data["label_tensor"],"node_features")

            masked_features=batch_flatten(masked_features,data["text_len_tensor"],self.device)
            self.flattened_mask=batch_flatten(mask,data["text_len_tensor"],self.device)
            
            graph_out_dae=self.gcn_dae(masked_features,edge_index,edge_type)
            graph_out = self.gcn(features, edge_index, edge_type)
            # if self.args.visualize:
            #     draw_Umap(self.args,graph_out,data["label_tensor"],"gnn_features")

            return graph_out,graph_out_dae,features
        else:
            features, edge_index, edge_type, edge_index_lengths = batch_graphify(
                node_features,
                data["text_len_tensor"],
                data["speaker_tensor"],
                self.wp,
                self.wf,
                self.edge_type_to_idx,
                self.device,
            )

            graph_out = self.gcn(features, edge_index, edge_type)
            return graph_out, features

    def forward(self, data):
        if self.args.use_graph_generator:
            graph_out,graph_out_dae,features = self.get_rep(data)
        else:
            graph_out, features = self.get_rep(data)
        if self.concat_gin_gout:
            out = self.clf(
                torch.cat([features, graph_out], dim=-1), data["text_len_tensor"]
            )
        else:
            out = self.clf(graph_out, data["text_len_tensor"])

        return out

    def get_loss(self, data):
        if self.args.use_graph_generator:
            graph_out,graph_out_dae,features = self.get_rep(data)
        else:
            graph_out, features = self.get_rep(data)

        if self.concat_gin_gout:
            loss = self.clf.get_loss(
                torch.cat([features, graph_out], dim=-1),
                data["label_tensor"],
                data["text_len_tensor"],
            )
        else:
            loss = self.clf.get_loss(
                graph_out, data["label_tensor"], data["text_len_tensor"]
            )

        if self.args.use_graph_generator:
            indices=self.flattened_mask>0
            logits=self.projection(graph_out_dae)
            mse_loss=F.mse_loss(logits[indices],features[indices],reduction="mean")
            loss=loss+mse_loss*10

        return loss
