from sentence_transformers import SentenceTransformer
from transformers import BertTokenizer,BertModel
import numpy as np
sbert_model = SentenceTransformer("paraphrase-distilroberta-base-v1")

# tokenizer = BertTokenizer.from_pretrained("/home/jiawei/COGMEN/emotion_recognition/bert-base-uncased")
# bert_model = BertModel.from_pretrained("/home/jiawei/COGMEN/emotion_recognition/bert-base-uncased")


class Sample:
    def __init__(self, vid, speaker, label, text, audio, visual, sentence):
        self.vid = vid
        self.speaker = speaker
        self.label = label
        self.text = text
        self.audio = audio
        self.visual = visual
        self.sentence = sentence
        # if dataset=="iemocap" or dataset=="iemocap_4":
        self.sbert_sentence_embeddings = sbert_model.encode(sentence)
        # if dataset=="mosei" or dataset=="mosei_2":
            # self.sbert_sentence_embeddings = np.array(self.text)
