import numpy as np
import torch

import cogmen

log = cogmen.utils.get_logger()


def batch_graphify(features, lengths, speaker_tensor, wp, wf, edge_type_to_idx, device):
    node_features, edge_index, edge_type = [], [], []
    batch_size = features.size(0)
    length_sum = 0
    edge_ind = []
    edge_index_lengths = []

    for j in range(batch_size):
        edge_ind.append(edge_perms(lengths[j].cpu().item(), wp, wf))

    for j in range(batch_size):
        cur_len = lengths[j].item()
        node_features.append(features[j, :cur_len, :])
        perms = edge_perms(cur_len, wp, wf)
        perms_rec = [(item[0] + length_sum, item[1] + length_sum) for item in perms]
        length_sum += cur_len
        edge_index_lengths.append(len(perms))
        for item, item_rec in zip(perms, perms_rec):
            edge_index.append(torch.tensor([item_rec[0], item_rec[1]]))

            speaker1 = speaker_tensor[j, item[0]].item()
            speaker2 = speaker_tensor[j, item[1]].item()
            if item[0] < item[1]:
                c = "0"
            else:
                c = "1"
            edge_type.append(edge_type_to_idx[str(speaker1) + str(speaker2) + c])

    node_features = torch.cat(node_features, dim=0).to(device)  # [E, D_g]
    edge_index = torch.stack(edge_index).t().contiguous().to(device)  # [2, E]
    edge_type = torch.tensor(edge_type).long().to(device)  # [E]
    edge_index_lengths = torch.tensor(edge_index_lengths).long().to(device)  # [B]

    return node_features, edge_index, edge_type, edge_index_lengths


def edge_perms(length, window_past, window_future):
    """
    Method to construct the edges of a graph (a utterance) considering the past and future window.
    return: list of tuples. tuple -> (vertice(int), neighbor(int))
    """

    all_perms = set()
    array = np.arange(length)
    for j in range(length):
        perms = set()

        if window_past == -1 and window_future == -1:
            eff_array = array
        elif window_past == -1:  # use all past context
            eff_array = array[: min(length, j + window_future + 1)]
        elif window_future == -1:  # use all future context
            eff_array = array[max(0, j - window_past) :]
        else:
            eff_array = array[
                max(0, j - window_past) : min(length, j + window_future + 1)
            ]

        for item in eff_array:
            perms.add((j, item))
        all_perms = all_perms.union(perms)
    return list(all_perms)


def getStat(data,device):
    nb_samples = 0
    N,C,D=data.shape[:3]
    print("N,C,D:",N,C,D)
    mean=torch.zeros(C).to(device)
    std=torch.zeros(C).to(device)
    mean+=data.mean(2).sum(0)
    std+=data.std(2).sum(0)
    nb_samples+=N
    mean/=nb_samples
    std/=nb_samples
    return list(mean.cpu().numpy()),list(std.cpu().numpy())

def batch_flatten(features, lengths,device):
    flatten_features = []
    batch_size = features.size(0)
    for j in range(batch_size):
        cur_len = lengths[j].item()
        flatten_features.append(features[j, :cur_len, :])
    flatten_features = torch.cat(flatten_features, dim=0).to(device)
    return flatten_features




def vsw_batch_graphify(features, lengths, speaker_tensor,window_size, edge_type_to_idx, device):
    node_features, edge_index, edge_type = [], [], []
    batch_size = features.size(0)
    length_sum = 0
    edge_index_lengths = []

    for j in range(batch_size):
        cur_len = lengths[j].item()
        cur_wp=window_size[j,:cur_len]
        cur_wf=cur_wp
        node_features.append(features[j, :cur_len, :])
        perms = vsw_edge_perms(cur_len, cur_wp, cur_wf)
        perms_rec = [(item[0] + length_sum, item[1] + length_sum) for item in perms]
        length_sum += cur_len
        edge_index_lengths.append(len(perms))
        for item, item_rec in zip(perms, perms_rec):
            edge_index.append(torch.tensor([item_rec[0], item_rec[1]]))

            speaker1 = speaker_tensor[j, item[0]].item()
            speaker2 = speaker_tensor[j, item[1]].item()
            if item[0] < item[1]:
                c = "0"
            else:
                c = "1"
            edge_type.append(edge_type_to_idx[str(speaker1) + str(speaker2) + c])

    node_features = torch.cat(node_features, dim=0).to(device)  # [E, D_g]
    edge_index = torch.stack(edge_index).t().contiguous().to(device)  # [2, E]
    edge_type = torch.tensor(edge_type).long().to(device)  # [E]
    edge_index_lengths = torch.tensor(edge_index_lengths).long().to(device)  # [B]

    return node_features, edge_index, edge_type, edge_index_lengths


def vsw_edge_perms(length, window_past, window_future):
    """
    Method to construct the edges of a graph (a utterance) considering the past and future window.
    return: list of tuples. tuple -> (vertice(int), neighbor(int))
    """

    all_perms = set()
    array = np.arange(length)
    # print("window_past:",window_past)
    for j in range(length):
        perms = set()
        wp=window_past[j].item()
        wf=window_future[j].item()
        if wp >= length:
            wp=-1
        if wf >= length:
            wf=-1
        if wp == -1 and wf == -1:
            eff_array = array
        elif wp == -1:  # use all past context
            eff_array = array[: min(length, j + wf + 1)]
        elif wf == -1:  # use all future context
            eff_array = array[max(0, j - wp) :]
        else:
            eff_array = array[
                max(0, j - wp) : min(length, j + wf + 1)
            ]

        for item in eff_array:
            perms.add((j, item))
        all_perms = all_perms.union(perms)
    return list(all_perms)


def get_masked_features(features,mask,noiseType,args):
    if noiseType =="mask":
        masked_features=features*(1-mask)
    if noiseType=="normal":
        noise=torch.normal(0.0,1.0,size=features.shape).to(args.device)
        masked_features=features+(noise*mask)
    
    return masked_features

def get_random_mask(features,ratio):
    probs=torch.full(features.shape,1/ratio)
    mask=torch.bernoulli(probs)
    return mask