Due to storage limitation, Data are availiable upon request.
